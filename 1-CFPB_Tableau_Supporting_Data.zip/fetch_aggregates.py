import calendar,csv,json,subprocess,pathlib
out=pathlib.Path(__file__).parent
monthly=[]; product={}
for year,month in [(2025,11),(2025,12)]+[(2026,m) for m in range(1,11)]:
    start=f'{year}-{month:02d}-01'; end=f'{year}-{month:02d}-{calendar.monthrange(year,month)[1]}'
    url=f'https://www.consumerfinance.gov/data-research/consumer-complaints/search/api/v1/?date_received_min={start}&date_received_max={end}&size=0'
    raw=subprocess.check_output(['curl','--fail','--silent','--show-error','-A','Mozilla/5.0',url])
    d=json.loads(raw); a=d['aggregations']; total=d['hits']['total']['value']
    timely={b['key']:b['doc_count'] for b in a['timely']['timely']['buckets']}
    yes=timely.get('Yes',0); no=timely.get('No',0)
    monthly.append([start,total,yes,no,total-yes-no])
    for b in a['product']['product']['buckets']: product[b['key']]=product.get(b['key'],0)+b['doc_count']
    (out/f'aggregate_{year}-{month:02d}.json').write_bytes(raw)
    print(start,total,flush=True)
with (out/'monthly_summary.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['month_start','complaints','timely_yes','timely_no','timely_unknown']);w.writerows(monthly)
with (out/'product_volume.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['product','complaints']);w.writerows(sorted(product.items(),key=lambda x:-x[1]))
assert sum(x[1] for x in monthly)==sum(product.values())
print('TOTAL',sum(x[1] for x in monthly))
